Differences in gameplay between the original version of Dark Ages and the remake:

Minor differences in worldmap/dungeons. This is primarily in order to give better graphics.
Major differences in towns. Although each town has the same shops and actors that it did before, the architecture is completely redone.
Combat is different. There is no longer a hit% stat. Instead, the % is built into your attack rating.
Related to the above difference, the blind spell now reduces attack/defense directly.
Chances for battle/run % are different.
Costs for armor/weapons are higher, as you can resell them at full price.
You must manually equip weapons/armor.
There are a few secrets hidden around. Pay close attention to the environment.
Fixed a small bug in the goblin castle.
Encounter rate in goblin castle is unchanged from the world at large.